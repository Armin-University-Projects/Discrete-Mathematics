﻿// This program encrypts the given word using the rsa algorithm
// it encrypts character by character

using System;
using System.Text.RegularExpressions;

namespace @Cryptography
{
    partial class Program
    {
        static void Main()
        {
            RSA rsa = new RSA();
            Console.WriteLine($"Public key pair: ({rsa.publicKey.e},{rsa.publicKey.n})\n");

            string? word;
            do
            {
                Console.Write("Enter a word to encrypt: ");
                word = Console.ReadLine();

            } while (String.IsNullOrEmpty(word) || !Regex.IsMatch(word, @"^[a-zA-Z]{1,}$")); // checking if it's a word

            rsa.Encrypt(word, out string encryptedWord);
            rsa.Decrypt(encryptedWord, out string decryptedWord);

            Console.WriteLine($"Encrypted: {encryptedWord}");
            Console.WriteLine($"Decrypted back: {decryptedWord}\n");


            do
            {
                Console.Write("Enter a message to decrypt: ");
                word = Console.ReadLine();

            } while (String.IsNullOrEmpty(word) || !Regex.IsMatch(word, @"^\d{1,}$")); // decrypted messages containg only numbers

            try
            {
                rsa.Decrypt(word, out decryptedWord);
                rsa.Encrypt(decryptedWord, out encryptedWord);

                if (encryptedWord != word)
                {
                    throw new Exception();
                }

                Console.WriteLine($"Decrypted: {decryptedWord}");
                Console.WriteLine($"Encrypted back: {encryptedWord}");
            }
            catch
            {
                Console.WriteLine("Invalid message to decrypt!");
            }
        }

        public static int GCD(int a, int b) // returns the greatest common divisor
        {
            while (a != 0 && b != 0)
            {
                if (a > b)
                    a %= b;
                else
                    b %= a;
            }

            return a | b;
        }
    }

    public sealed class RSA
    {
        public readonly Key.Public publicKey;
        private readonly Key.Private privateKey;

        private int partLength; // each word has a fixed length in the encrypted message

        public RSA()
        {
            int p = 11, q = 71; // in a normal situation these would be generated randomly

            this.publicKey = GeneratePublicKey(p, q);
            this.privateKey = GeneratePrivateKey(p, q);

            partLength = 1;
            for (int i = publicKey.n; i >= 10; i /= 10)
            {
                partLength++;
            }
        }

        public void Encrypt(string message, out string result)
        {
            result = "";

            foreach (char c in message)
            {
                int num = (int)(c - 'A') + 1; // each character is given a fixed number

                string encrypted = num.PowMod(publicKey.e, publicKey.n).ToString();
                result += encrypted.FixLength(partLength);
            }
        }

        public void Decrypt(string message, out string result)
        {
            if (message.Length % partLength != 0 || !Regex.IsMatch(message, @"^\d{1,}$"))
            {
                throw new Exception("Invalid encrypted message!");
            }

            result = "";

            for (int i = 0; i < message.Length; i += partLength)
            {
                string toDecrypt = message.Substring(i, partLength);
                result += ((char)(int.Parse(toDecrypt).PowMod(privateKey.d, privateKey.n) + (int)'A' - 1)).ToString();
            }
        }

        public static class Key
        {
            public readonly struct Public // pair of (e,n)
            {
                public readonly int n;
                public readonly int e;

                public Public(int n, int e)
                {
                    this.n = n;
                    this.e = e;
                }
            }

            public readonly struct Private // pair of (d,n)
            {
                public readonly int n;
                public readonly int d;

                public Private(int n, int d)
                {
                    this.n = n;
                    this.d = d;
                }
            }
        }

        private Key.Public GeneratePublicKey(int p, int q) // based on RSA algorithm
        {
            int n = p * q;
            int phi = (p - 1) * (q - 1);

            int e = new Random().Next(2, n); // generating a coprime of phi in the range [0..n)
            while (Program.GCD(phi, e) != 1)
            {
                e = new Random().Next(2, n);
            }

            return new Key.Public(n, e);
        }

        private Key.Private GeneratePrivateKey(int p, int q) // based on RSA algorithm
        {
            int n = p * q;
            int phi = (p - 1) * (q - 1);

            for (int d = 1; d < n; d++) // generating the inverse of e in the ring Z(phi)
            {
                if ((this.publicKey.e * d) % phi == 1)
                {
                    return new Key.Private(n, d);
                }
            }

            throw new Exception("something went wrong!");
        }
    }

    public static class Extentions
    {
        public static int PowMod(this int num, int exponent, int modulo) // calculates (num ^ exponent) % modulo
        {
            int remainder = num % modulo;

            while (exponent > 1)
            {
                remainder = (remainder * num) % modulo;
                exponent--;
            }

            return remainder; 
        }

        public static string FixLength(this string word, int partLength) // fixes the word's length by inserting zeros at the begining
        {
            while (word.Length < partLength)
            {
                word = "0" + word;
            }

            return word;
        }
    }
}

// Source used for the RSA algorithm: Mathematics for Computer Science page 380