﻿using System;
using System.Collections.Generic;

namespace GraphTree
{
    public class Program
    {
        private static void Main()
        {
            Console.WriteLine("Enter the size of the matrix: ");
            int size = GetNum(1);
            int[,] adjacent_matrix = new int[size,size];

            for (int i = 0; i < size; i++)
            {
                Console.WriteLine($"Enter row number {i + 1}: ");
                int[] nums = GetNums(size, 0, 1);
                for (int j = 0; j < size; j++)
                {
                    adjacent_matrix[i, j] = nums[j];
                }
            }

            if (!IsValidAdjacentMatrix(adjacent_matrix, size))
            {
                Console.WriteLine("Given adjacent matrix is not valid!");
                return;
            }

            if (!IsSimpleGraph(adjacent_matrix, size))
            {
                Console.WriteLine("Given graph is not simple!");
                return;
            }

            if (!IsConnectedGraph(adjacent_matrix, size))
            {
                Console.WriteLine("Given graph is not connected!");
                return;
            }

            Console.WriteLine("Enter the root's id: ");
            int id = GetNum(1, size);

            int[,] copy = new int[size, size]; // a copy of the adjacent matrix so we can use it twice
            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    copy[i, j] = adjacent_matrix[i, j];
                }
            }

            Node root = new Node(id);
            Console.WriteLine("\n\n\nDFS Traversal: \n");
            root.DFS_traversal(root, copy, size);

            root = new Node(id);
            Console.WriteLine("\n\n\nBFS Traversal: \n");
            root.BFS_traversal(adjacent_matrix, size);
        }

        public static int GetNum(int min = int.MinValue, int max = int.MaxValue) // getting a number within the range from the user
        {
            while (true)
            {
                try
                {
                    int num = int.Parse(Console.ReadLine());

                    if (num < min || min > max)
                    {
                        Console.WriteLine("Number is not in the valid range!");
                        continue;
                    }

                    return num;
                }
                catch (Exception)
                {
                    Console.WriteLine("You must enter a number!");
                }
            }
        }

        public static int[] GetNums(int size, int min = int.MinValue, int max = int.MaxValue) // getting numbers withing the range from the user
        {
            while (true)
            {
                string[] inputs = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries);
                int[] nums = new int[size];

                try
                {
                    for (int i = 0; i < size; i++)
                    {
                        nums[i] = int.Parse(inputs[i]);
                    }

                    return nums;
                }
                catch (Exception)
                {
                    Console.WriteLine("You must enter numbers");
                }
            }
        }

        public static bool IsValidAdjacentMatrix(int[,] adjacentMatrix, int size) // if a vertix is connected to another one then the other one should be connected to it as well
        {
            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    if (adjacentMatrix[i, j] != adjacentMatrix[j, i])
                    {
                        return false;
                    }
                }
            }

            return true;
        }

        public static bool IsSimpleGraph(int[,] adjacent_matrix, int size) // if Aii isn't zero then the vertix(i) has an edge to itselft
        {
            for (int i = 0; i < size; i++)
            {
                if (adjacent_matrix[i, i] == 1)
                {
                    return false;
                }
            }

            return true;
        }

        public static bool IsConnectedGraph(int[,] adjacent_matrix, int size) // if a row/column in completely empty then the graph is not connected
        {
            for (int i = 0; i < size; i++)
            {
                int j = 0;

                while (j < size)
                {
                    if (adjacent_matrix[i, j] == 1)
                    {
                        break;
                    }

                    j++;
                }

                if (j == size)
                {
                    return false;
                }
            }

            return true;
        }
    }

    public class Node
    {
        public int Id { get; }
        public string Text { get; private set; }
        public Node? Parent { get; set; }
        public List<Node> Children { get; set; }

        public Node(int id)
        {
            Parent = null;
            this.Id = id;
            Text = $" {Id} ";
            Children = new List<Node>();
        }

        public void DFS_traversal(Node root, int[,] adjacent_matrix, int size)
        {
            root.Print();
            Console.WriteLine();

            for (int k = 0; k < size; k++)
            {
                if (adjacent_matrix[k, Id - 1] == 1 && !root.IsDuplicateId(k + 1))
                {
                    Node node = new Node(k + 1);
                    this.AddChild(node);
                    EmptyMatrix(ref adjacent_matrix, size, Id, node.Id);
                    node.DFS_traversal(root, adjacent_matrix, size); // continues until the node is not able to connect to any other vertix
                }
            }
        }

        public void BFS_traversal(int[,] adjacent_matrix, int size)
        {
            this.Print();
            Console.WriteLine();

            List<Node> AllChildren = new List<Node>();

            for (int k = 0; k < size; k++) // finding the root's children
            {
                if (adjacent_matrix[k, this.Id - 1] == 1 && !this.IsDuplicateId(k + 1))
                {
                    Node node = new Node(k + 1);
                    this.AddChild(node);
                    EmptyMatrix(ref adjacent_matrix, size, this.Id, node.Id);
                }
            }
            AllChildren.AddRange(this.Children);
            

            while (AllChildren.Count != 0)
            {
                List<Node> children = new List<Node>();
                children.AddRange(AllChildren);
                AllChildren.Clear();

                foreach (Node child in children) // finding all of the children's children
                {
                    for (int k = 0; k < size; k++)
                    {
                        if (!this.IsDuplicateId(k + 1) && adjacent_matrix[k, child.Id - 1] == 1)
                        {
                            Node node = new Node(k + 1);
                            child.AddChild(node);
                            EmptyMatrix(ref adjacent_matrix, size, child.Id, node.Id);
                        }
                    }

                    AllChildren.AddRange(child.Children);
                }

                this.Print();
                Console.WriteLine();
            }
        }

        private static void EmptyMatrix(ref int[,] matrix, int size, int id_A, int id_B) // empties the Aij and Aji when i->j/j->i is added to the tree
        {
            matrix[id_A - 1, id_B - 1] = 0;
            matrix[id_B - 1, id_A - 1] = 0;
        }

        private bool IsDuplicateId(int id) // if a node with this id already exists within the tree
        {
            if (this.Id == id)
            {
                return true;
            }

            foreach (Node node in Children)
            {
                if (node.IsDuplicateId(id))
                {
                    return true;
                }
            }

            return false;
        }

        private static void Print(List<Node> nodes) // prints the nodes in the list and their children
        {
            List<Node> AllChildren = new List<Node>();
            foreach (Node node in nodes)
            {
                Console.Write(node.Text);
                AllChildren.AddRange(node.Children);

                if (node.Children.Count == 0)
                {
                    for (int i = 1; i <= node.Text.Length; i++)
                    {
                        Console.Write(" ");
                    }
                }
            }
            Console.WriteLine();

            if (AllChildren.Count != 0)
            {
                Print(AllChildren);
            }
        }

        public void Print() // prints a tree with (this) as the root
        {
            Console.WriteLine(this.Text);
            Print(this.Children);
        }

        public void AddChild(Node node) // changing the text of the nodes while a child is added
        {
            Node? parent = this;
            for (string spaces = " "; parent != null; spaces += " ")
            {
                foreach (Node child in this.Children)
                {
                    child.Text = " " + child.Text;
                }
                parent.Text = spaces + parent.Text + spaces;
                parent = parent.Parent;
            }
            this.Children.Add(node);
            node.Parent = this;
        }
    }
}

// *namayesh drakht ha besyar bad ast, ama algorithm ha dorost kar mikonand*
// *node's id = index + 1*

// DFS anghadr pish miravad to digar vertix baraye vasl shodan namanad sepas be aghab bar migardad
// ta as node haye ghabli betavanad in ravesh ra piade konad be hamin dalil bayad az
// recursion baraye algorithm on estefade konim

// BFS dar yek marhale tamame children yek node ra peida mikonad va dar marhale bad tamam 
// children on children hara peyda mikonad be hamin dalil mitavan ba loop/recursion
// algorithm on ra peyda kard