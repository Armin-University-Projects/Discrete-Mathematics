-explanations are through comments

-comments at the end of code are the summary

-for running the codes open the .sin file at each folder (recommanded IDE: Visual Studio)